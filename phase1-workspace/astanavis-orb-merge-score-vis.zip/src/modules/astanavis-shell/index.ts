export { astanavisShellModule } from "./module";
