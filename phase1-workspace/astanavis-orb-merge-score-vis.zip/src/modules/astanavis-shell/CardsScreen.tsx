import { useEffect, useRef, useState, type ReactNode } from "react";
import { useIDosGamesClient, useUserState } from "@idosgames/react";
import { Button, Icon, panel, useGameLayout, v } from "@idosgames/react/ui";
import { isFail } from "@idosgames/core";
import {
  CARD_MERGE_COUNT,
  canCombineTierOne,
  cardDefinitionsFromItems,
  createPendingLock,
  groupCards,
  type CardsInventory,
  type AstanaVisCardDefinition,
  type CardCharacterGroup,
} from "./cards-model";

export function makeCardsScreen() {
  return function CardsScreen(): ReactNode {
    return <Cards />;
  };
}

function Cards(): ReactNode {
  const client = useIDosGamesClient();
  const userState = useUserState();
  const layout = useGameLayout();
  const [definitions, setDefinitions] = useState<AstanaVisCardDefinition[]>([]);
  const [refreshing, setRefreshing] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingCharacters, setPendingCharacters] = useState<Set<string>>(() => new Set());
  const [notice, setNotice] = useState<string | null>(null);
  const pendingRef = useRef(createPendingLock());

  useEffect(() => {
    let mounted = true;
    void (async () => {
      const [inventoryResult, craftResult, titleConfigResult] = await Promise.all([
        client.cache.ensureState(["InventoryV2"], { maxAgeMs: 0 }),
        client.craft.getDefinitions(),
        client.title.getTitlePublicConfiguration(),
      ]);
      if (!mounted) return;
      setRefreshing(false);
      if (isFail(inventoryResult)) setError("Inventory could not be refreshed. Try reopening Cards.");
      if (isFail(craftResult)) setError("Craft recipes could not be loaded. Try reopening Cards.");
      if (isFail(titleConfigResult)) setError("Card definitions could not be loaded from the Title configuration.");
      else setDefinitions(cardDefinitionsFromItems(titleConfigResult.data.Item?.Catalogs?.Item?.Items));
    })();
    return () => { mounted = false; };
  }, [client]);

  const groups = groupCards(definitions, userState?.InventoryV2 as CardsInventory | undefined);

  const combine = async (group: CardCharacterGroup) => {
    if (!canCombineTierOne(group.tierOneAmount)) return;
    const source = group.cards.find((card) => card.tier === 1);
    const target = group.cards.find((card) => card.tier === 2);
    if (!source || !target || !source.collectionId || !source.craftRarityId || !target.craftRarityId) {
      setError("This card has no valid server recipe configuration.");
      return;
    }
    if (!pendingRef.current.tryAcquire(group.characterId)) return;

    // One request consumes five stackable T1 copies. The server validates the isolated
    // CollectionID + craft RarityID pool and atomically applies the InventoryV2 delta.
    setPendingCharacters(pendingRef.current.snapshot());
    setError(null);
    setNotice(null);
    try {
      const definitionsResult = await client.craft.getDefinitions();
      if (isFail(definitionsResult)) throw new Error("Craft recipes could not be loaded.");
      const recipe = definitionsResult.data.CraftDefinitions?.Definitions?.[`merge-${group.characterId}-t1-t2`];
      if (
        recipe?.Type !== "TradeUpCollection" ||
        recipe.CollectionID !== source.collectionId ||
        recipe.InputRarityID !== source.craftRarityId ||
        recipe.OutputRarityID !== target.craftRarityId ||
        recipe.RequiredItemCount !== CARD_MERGE_COUNT
      ) throw new Error("The server recipe does not match this card. No cards were consumed.");

      const result = await client.craft.craft(
        recipe.CraftID ?? `merge-${group.characterId}-t1-t2`,
        Array.from({ length: CARD_MERGE_COUNT }, () => source.itemID),
      );
      if (isFail(result)) {
        if (result.reason === "connection") {
          const inventoryRefresh = await client.cache.ensureState(["InventoryV2"], { maxAgeMs: 0 });
          if (isFail(inventoryRefresh)) {
            throw new Error("Network response was lost and inventory could not be checked. Reopen Cards before trying again.");
          }
          throw new Error("Network response was lost. Inventory was refreshed; check the counts before combining again.");
        }
        throw new Error(result.error || `Craft failed (${result.reason}).`);
      }
      const outputID = result.data.Results?.[0]?.Output?.ItemID;
      if (outputID !== target.itemID) {
        setNotice(`Combine completed. Server returned ${outputID ?? "an output"}; refresh Cards to confirm.`);
      } else {
        setNotice(`${group.characterName} · T1 → T2 complete`);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Combine failed. Try again.");
    } finally {
      pendingRef.current.release(group.characterId);
      setPendingCharacters(pendingRef.current.snapshot());
    }
  };

  return (
    <section style={{ ...panel, width: "100%", maxWidth: 980, margin: "0 auto", padding: "clamp(16px, 3vw, 28px)", display: "grid", gap: 18, boxSizing: "border-box" }}>
      <header style={{ display: "flex", alignItems: "end", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ color: v.red, fontSize: 11, fontWeight: 900, letterSpacing: 2.5 }}>NEKO STARS · COLLECTION</div>
          <h1 style={{ margin: "5px 0 0", color: v.text, fontSize: "clamp(24px, 5vw, 36px)", lineHeight: 1.05 }}>CARDS</h1>
        </div>
        <div style={{ color: v.textDim, fontSize: 12, fontWeight: 800, letterSpacing: 1 }}>5 × T1 <span style={{ color: v.red }}>→</span> 1 × T2</div>
      </header>

      {refreshing ? <div role="status" style={muted}>Syncing InventoryV2…</div> : null}
      {error ? <div role="alert" style={{ ...muted, color: v.red }}>{error}</div> : null}
      {notice ? <div role="status" style={{ ...muted, color: v.green }}>{notice}</div> : null}

      {groups.length === 0 ? (
        <div style={{ ...panel, padding: 24, color: v.textDim, textAlign: "center" }}>
          Card definitions are not loaded yet. Add the AstanaVis card Items to the Title configuration.
        </div>
      ) : (
        <div style={{ display: "grid", gap: 14 }}>
          {groups.map((group) => (
            <article key={group.characterId} style={{ ...panel, padding: "clamp(12px, 2.5vw, 20px)", display: "grid", gridTemplateColumns: layout === "phone" ? "minmax(0, 1fr)" : "minmax(0, 1fr) auto", alignItems: "center", gap: 14 }}>
              <div style={{ minWidth: 0 }}>
                <h2 style={{ color: v.text, margin: "0 0 10px", fontSize: 16, letterSpacing: 1.3 }}>{group.characterName}</h2>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  {group.cards.map((card) => (
                    <CardTile key={card.itemID} tier={card.tier} amount={card.amount} name={card.name} imagePath={card.imagePath} rarity={card.rarity} locked={card.isLocked} />
                  ))}
                </div>
              </div>
              <Button
                tone="red"
                size="sm"
                disabled={!canCombineTierOne(group.tierOneAmount) || pendingCharacters.has(group.characterId) || refreshing}
                busy={pendingCharacters.has(group.characterId)}
                onClick={() => void combine(group)}
                title={`Combine ${CARD_MERGE_COUNT} Tier 1 cards`}
                style={{ whiteSpace: "nowrap" }}
              >
                COMBINE {CARD_MERGE_COUNT}
              </Button>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function CardTile({ tier, amount, name, imagePath, rarity, locked }: { tier: number; amount: number; name: string; imagePath: string | null; rarity: string; locked: boolean }): ReactNode {
  return (
    <div aria-label={locked ? `Locked Tier ${tier} card` : `${name}, Tier ${tier}, ${rarity}, ${amount} owned`} style={{ width: "clamp(94px, 26vw, 132px)", minHeight: 130, boxSizing: "border-box", border: `1px solid ${locked ? v.panelEdge : v.red}`, background: v.panelDeep, padding: 8, display: "grid", gridTemplateRows: "1fr auto auto", gap: 5, textAlign: "center" }}>
      <div style={{ position: "relative", minHeight: 74, display: "grid", placeItems: "center", background: locked ? "#242424" : "#351f20", color: locked ? v.textDim : v.gold, overflow: "hidden" }}>
        {locked ? <span aria-hidden="true" style={{ fontSize: 46, fontWeight: 900, filter: "blur(1px)", opacity: 0.7 }}>?</span> : imagePath ? <img src={imagePath} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Icon glyph="user" size={40} />}
        <span style={{ position: "absolute", left: 5, top: 4, color: v.text, fontSize: 9, fontWeight: 900 }}>T{tier}</span>
      </div>
      <strong style={{ color: locked ? v.textDim : v.text, fontSize: 11, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{locked ? "???" : name}</strong>
      <span style={{ color: v.textDim, fontSize: 10, textTransform: "uppercase", letterSpacing: 0.6 }}>{locked ? "LOCKED" : `${rarity} · x${amount}`}</span>
    </div>
  );
}

const muted = { color: v.textDim, fontSize: 12, fontWeight: 700 } as const;
