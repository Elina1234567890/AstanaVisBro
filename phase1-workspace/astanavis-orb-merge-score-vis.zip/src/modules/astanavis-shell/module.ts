import { defineModule, type Module } from "@idosgames/module-sdk";
import { t } from "./i18n";
import { makeCardsScreen } from "./CardsScreen";
import { makeStoreScreen } from "./StoreScreen";

// Navigation only: remove the Store registration before installing the real Store module.
export const astanavisShellModule: Module = defineModule({
  id: "astanavis-shell",
  meta: { name: "AstanaVis", type: "app", engine: "dom" },
  setup(ctx) {
    ctx.features.register({
      id: "cards", label: t("cards"), icon: "bag", group: "economy",
      Screen: makeCardsScreen(),
    });
    ctx.features.register({
      id: "store", label: t("store"), icon: "shop", group: "economy",
      Screen: makeStoreScreen(),
    });
  },
});
