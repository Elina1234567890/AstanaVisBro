export { astanavisShellModule } from "./module";
